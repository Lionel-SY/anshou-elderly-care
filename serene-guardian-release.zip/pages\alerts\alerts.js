/* 家人端 · 告警中心：列表 + 详情弹窗（含核验倒计时） */
const store = require('../../utils/store.js')

Page({
  data: {
    tab: 'all', list: [], cur: null, eld: {}, cdText: '--:--', cdPct: 100,
    escOpen: false, escCtx: {}, esc: { emergency: true, contact: true, property: false, broadcast: false }
  },

  onShow() {
    if (!store.db.sess) { wx.reLaunch({ url: '/pages/login/login' }); return }
    this._r = () => this.render()
    this._n = id => this.onNewAlert(id)
    store.on('alerts', this._r); store.on('alert_new', this._n)
    this.render()
  },
  onHide() { this.unsub(); this.stopCd() },
  onUnload() { this.unsub(); this.stopCd() },
  unsub() {
    if (this._r) store.off('alerts', this._r)
    if (this._n) store.off('alert_new', this._n)
  },

  setTab(e) { this.setData({ tab: e.currentTarget.dataset.t }); this.render() },

  chip(a) {
    return a.status === 'pending' ? ['待处理', 'red']
      : a.status === 'acked' ? ['已确认 · 处理中', 'amber']
        : a.status === 'auto' ? ['已自动升级救援', 'red'] : ['已处理', 'green']
  },

  render() {
    const e = store.activeElder()
    let list = store.db.alerts.filter(a => !e || a.elderId === e.id)
    if (this.data.tab === 'pending') list = list.filter(a => a.status === 'pending')
    if (this.data.tab === 'done') list = list.filter(a => a.status !== 'pending')
    this.setData({
      list: list.map(a => {
        const c = this.chip(a)
        return {
          id: a.id, ic: store.TYPE[a.type].ic, t: store.TYPE[a.type].t,
          chipTxt: c[0], chipCls: c[1],
          time: store.fmtDT(a.ts), room: a.room, src: a.src, desc: a.desc,
          crit: store.TYPE[a.type].crit, resolved: a.status !== 'pending'
        }
      })
    })
    /* 若详情弹窗开着，同步刷新其状态 */
    if (this.data.cur) {
      const cur = store.db.alerts.find(x => x.id === this.data.cur.id)
      if (cur) this.fillCur(cur)
    }
  },

  onNewAlert(id) {
    const a = store.db.alerts.find(x => x.id === id)
    if (!a) return
    if (store.TYPE[a.type].crit && !this.data.cur) this.openDetail({ currentTarget: { dataset: { id } } })
    else store.toast('🔔 收到' + store.TYPE[a.type].t)
  },

  fillCur(a) {
    const e = store.db.elders.find(x => x.id === a.elderId) || {}
    this.setData({
      cur: {
        id: a.id, ic: store.TYPE[a.type].ic, t: store.TYPE[a.type].t,
        status: a.status, deadline: a.deadline,
        src: a.src, timeFull: store.fmtDT(a.ts), time: store.fmtT(a.ts),
        room: a.room, addr: a.addr, hr: a.hr, desc: a.desc,
        logs: a.timeline.map(t => ({ ts: t.ts, time: store.fmtT(t.ts), text: t.text }))
      },
      eld: {
        name: e.name || '长辈',
        address: e.address || '未填写',
        diseases: (e.diseases || []).join('、') || '无特殊病史记录',
        meds: (e.meds || []).map(m => m.name + ' ' + m.time).join('；') || '无',
        contacts: (e.contacts || []).map(c => c.name + ' ' + c.phone).join('；') || '未填写'
      }
    })
  },

  openDetail(e) {
    const a = store.db.alerts.find(x => x.id === e.currentTarget.dataset.id)
    if (!a) return
    const el = store.db.elders.find(x => x.id === a.elderId) || {}
    const contacts = (el.contacts || []).filter(c => c.name)
    this.setData({
      escOpen: false,
      esc: { emergency: true, contact: contacts.length > 0, property: !!el.propertyPhone, broadcast: false },
      escCtx: {
        hasContacts: contacts.length > 0,
        contactTxt: contacts.length ? contacts.map(c => c.name + (c.phone ? ' ' + c.phone : '')).join('、') : '档案未填写紧急联络人',
        hasProperty: !!el.propertyPhone,
        propertyTxt: el.propertyPhone ? '物业电话 ' + el.propertyPhone : '未填写 · 请先到档案页添加'
      }
    })
    this.fillCur(a)
    this.startCd()
  },
  closeDetail() { this.setData({ cur: null, escOpen: false }); this.stopCd() },
  noop() { },

  /* 选择性升级救援 */
  openEsc() { this.setData({ escOpen: true }) },
  cancelEsc() { this.setData({ escOpen: false }) },
  toggleEsc(e) {
    const k = e.currentTarget.dataset.k
    if (k === 'contact' && !this.data.escCtx.hasContacts) { store.toast('请先在档案页添加紧急联络人'); return }
    if (k === 'property' && !this.data.escCtx.hasProperty) { store.toast('请先在档案页填写物业电话'); return }
    this.setData({ ['esc.' + k]: !this.data.esc[k] })
  },
  confirmEsc() {
    const s = this.data.esc
    if (!s.emergency && !s.contact && !s.property && !s.broadcast) { store.toast('请至少选择一项救援方式'); return }
    store.resolveAlert(this.data.cur.id, 'acked', s)
    this.closeDetail()
  },

  /* 核验倒计时（500ms 刷新） */
  startCd() {
    this.stopCd()
    const tick = () => {
      const cur = this.data.cur && store.db.alerts.find(x => x.id === this.data.cur.id)
      if (!cur || cur.status !== 'pending' || !cur.deadline) { this.stopCd(); return }
      const left = Math.max(0, cur.deadline - Date.now())
      this.setData({
        cdText: store.pad(Math.floor(left / 60000)) + ':' + store.pad(Math.floor(left % 60000 / 1000)),
        cdPct: left / (store.db.settings.verify * 1000) * 100
      })
    }
    tick()
    this._cd = setInterval(tick, 500)
  },
  stopCd() { if (this._cd) { clearInterval(this._cd); this._cd = null } },

  resolveDone(e) { store.resolveAlert(e.currentTarget.dataset.id, 'done'); this.closeDetail() },
  demo(e) { store.toast(e.currentTarget.dataset.t) }
})
