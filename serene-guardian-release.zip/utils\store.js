/* ============================================================
   Serene Guardian · 数据中心 + 感知设备模拟引擎（小程序版）
   存储：wx.Storage（替代 localStorage）；跨页联动：内部事件总线
   ============================================================ */
const KEY = { sess: 'sg_session', elders: 'sg_elders', alerts: 'sg_alerts', events: 'sg_events', device: 'sg_device', settings: 'sg_settings' }
const read = (k, d) => { try { const v = wx.getStorageSync(k); return (v === '' || v === null || v === undefined) ? d : v } catch (e) { return d } }
const write = (k, v) => { try { wx.setStorageSync(k, v) } catch (e) { console.error('[store] 写入失败', k, e) } }
let db = {
  sess: read(KEY.sess, null),
  elders: read(KEY.elders, []),
  alerts: read(KEY.alerts, []),
  events: read(KEY.events, []),
  device: read(KEY.device, null),
  settings: Object.assign({ verify: 60 }, read(KEY.settings, {}))
}
function persist() { write(KEY.elders, db.elders); write(KEY.alerts, db.alerts); write(KEY.events, db.events); write(KEY.device, db.device); write(KEY.settings, db.settings) }

/* ---------- 事件总线（页面订阅刷新） ---------- */
const bus = {}
function on(evt, fn) { (bus[evt] = bus[evt] || []).push(fn) }
function off(evt, fn) { if (bus[evt]) bus[evt] = bus[evt].filter(f => f !== fn) }
function emit(evt, data) { (bus[evt] || []).slice().forEach(fn => { try { fn(data) } catch (e) { console.error('[bus]', evt, e) } }) }

/* ---------- 工具 ---------- */
const pad = n => String(n).padStart(2, '0')
const fmtT = ts => { const d = new Date(ts); return pad(d.getHours()) + ':' + pad(d.getMinutes()) }
const fmtDT = ts => { const d = new Date(ts); return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + fmtT(ts) }
const todayKey = () => { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() }
const uid = () => 'x' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
function toast(t) { wx.showToast({ title: String(t).slice(0, 26), icon: 'none', duration: 2600 }) }
function pushEvent(icon, text, kind) {
  db.events.unshift({ ts: Date.now(), icon, text, kind: kind || 'life' })
  db.events = db.events.slice(0, 80); persist(); emit('events')
}
function pushLog(a, text) { a.timeline.unshift({ ts: Date.now(), text }) }

/* ---------- 当前长辈 ---------- */
function activeElder() {
  const id = read('sg_curElder', '')
  return db.elders.find(e => e.id === id) || db.elders[0] || null
}
function setCurElder(id) { write('sg_curElder', id); emit('elders'); emit('device') }

/* ---------- 档案向导自动打开标记（登录后跳档案页自动弹建档） ---------- */
let wizardFlag = false
function requestWizard() { wizardFlag = true }
function consumeWizard() { const f = wizardFlag; wizardFlag = false; return f }

/* ---------- 感知设备模拟：手环 + AI视觉 + 毫米波 + 睡眠垫 ---------- */
const ROOMS = ['客厅', '卧室', '厨房', '卫生间', '庭院']
const POSTURE_TEXT = { standing: '姿态正常 · 站立', walking: '活动 · 行走中', lying: '异常姿态 · 水平倒地' }
let sim = null
function ensureDevice() {
  if (!sim) {
    sim = db.device || { hr: 74, steps: 1200, activity: 'rest', room: '客厅', battery: 88, hrHighTicks: 0, forceHR: false, ts: Date.now(), sleep: '23:05 – 06:32 · 7小时27分', outdoor: false, posture: 'standing', fallAt: 0 }
    db.device = sim; persist()
    setTimeout(() => {
      pushEvent('🌙', '昨夜睡眠自动录入：' + sim.sleep + ' · 深睡占比良好')
      pushEvent('🛏️', '06:48 起床晨动，卧室红外步态平稳')
      pushEvent('🧍', 'AI视觉识别：长辈当前姿态 · 客厅站立', 'posture')
    }, 600)
  }
  return sim
}
const getSim = () => sim
let engineOn = false
function startEngine() {
  if (engineOn) return; engineOn = true
  setInterval(() => {                     // 感知设备每 2 秒上报一次
    if (!db.sess || !db.elders.length) return
    ensureDevice()
    const d = sim; d.ts = Date.now()
    /* 手环心率 */
    if (d.forceHR) { d.hr = Math.min(158, d.hr + 6 + Math.random() * 4); d.hrHighTicks++ }
    else {
      const base = d.activity === 'walk' ? 84 : 74
      d.hr += (base - d.hr) * .25 + (Math.random() - .5) * 5
      d.hr = Math.round(Math.min(120, Math.max(55, d.hr))); d.hrHighTicks = 0
    }
    /* 活动状态机（毫米波 + 手环融合） */
    if (d.posture !== 'lying' && Math.random() < .03) {
      if (d.activity === 'rest') { d.activity = 'walk'; d.posture = 'walking'; pushEvent('🚶', '开始活动 · 在' + d.room + '走动，步态平稳', 'posture') }
      else {
        d.activity = 'rest'; d.posture = 'standing'
        const nr = ROOMS[Math.floor(Math.random() * ROOMS.length)]
        if (nr !== d.room) { d.room = nr; pushEvent('🏠', '移动至' + nr + '，位置已自动更新', 'posture') }
        else pushEvent('🛋️', '回到' + d.room + '休息，姿态恢复站立', 'posture')
      }
    }
    if (d.activity === 'walk') d.steps += Math.floor(6 + Math.random() * 16)
    d.battery = Math.max(5, d.battery - 0.002)
    persist()
    /* 规则引擎：心率过高（手环） */
    if (d.hrHighTicks >= 5 && Date.now() - (db.hrCool || 0) > 10 * 60 * 1000) {
      db.hrCool = Date.now(); d.forceHR = false; d.hrHighTicks = 0
      sendAlert('hr_high', { hr: Math.round(d.hr) })
    }
    emit('device')
  }, 2000)
}

/* ---------- 报警核心 ---------- */
const TYPE = {
  fall: { t: 'AI识别疑似跌倒', ic: '🚨', crit: true },
  hr_high: { t: '心率过高预警', ic: '❤️', crit: true },
  sos: { t: '一键紧急报警', ic: '🆘', crit: true }
}
function sendAlert(type, opt) {
  opt = opt || {}; const e = activeElder(); if (!e) return
  const d = sim || {}
  const srcMap = { fall: '客厅AI视觉守护仪 + 毫米波监测仪（后端姿态录入）', hr_high: '手环·心率监测', sos: '老人端·一键报警' }
  const descMap = {
    fall: 'AI姿态识别：由直立转为水平倒地，持续静止 ' + Math.floor(20 + Math.random() * 40) + ' 秒，置信度 ' + (opt.conf || 89) + '%，心率快速上升',
    hr_high: '心率持续 ' + (opt.hr || d.hr || 136) + ' bpm，超过安全阈值（125 bpm），活动状态：' + (d.activity === 'walk' ? '行走' : '静息'),
    sos: '老人主动按下 SOS 紧急按钮，请求家人立即回应'
  }
  const a = {
    id: uid(), elderId: e.id, type, ts: Date.now(), status: 'pending',
    room: d.room || '客厅', loc: e.loc || null, addr: e.address || '', hr: opt.hr || Math.round((d && d.hr) || 76),
    src: srcMap[type], desc: descMap[type],
    deadline: (type === 'fall' || type === 'hr_high') ? Date.now() + db.settings.verify * 1000 : null,
    timeline: [{ ts: Date.now(), text: '感知设备后端录入异常数据，系统自动启动多方案紧急响应' }]
  }
  db.alerts.unshift(a); persist()
  pushEvent(TYPE[type].ic, TYPE[type].t + ' · ' + a.room + ' · 心率 ' + a.hr + ' bpm')
  try { wx.vibrateLong({}) } catch (err) { }
  syncBadge()
  emit('alert_new', a.id); emit('alerts')
}
function resolveAlert(id, res) {
  const a = db.alerts.find(x => x.id === id); if (!a) return
  if (res === 'done') {
    a.status = 'done'; pushLog(a, '家人已确认长辈平安，警报解除，事件闭环')
    pushEvent('✅', '家人确认平安 · 警报已解除'); resetPosture('家人已确认平安'); toast('已确认平安，警报解除')
  } else {
    opts = opts || {}
    const acts = []
    if (opts.emergency) acts.push('拨打 120 急救')
    if (opts.contact) acts.push('通知紧急联络人')
    if (opts.property) acts.push('通知小区物业')
    if (opts.broadcast) acts.push('发起小区互助广播')
    const txt = acts.length ? acts.join('、') : '等待家人进一步处置'
    a.status = 'acked'; a.deadline = null
    pushLog(a, '家人确认异常，已升级紧急救援：' + txt)
    pushEvent('🆘', '已升级紧急救援 · ' + txt); resetPosture('救援已启动')
    toast(acts.length ? '已按所选渠道启动救援' : '已标记异常，等待进一步处置')
  }
  persist(); syncBadge(); emit('alerts')
}
function resetPosture(reason) {
  if (sim && sim.posture === 'lying') {
    sim.posture = 'standing'; sim.activity = 'rest'; persist()
    pushEvent('🧍', '长辈已起身恢复站立 · ' + reason, 'posture'); emit('device')
  }
}
/* 自动升级看门狗：核验倒计时超时未确认 → 自动升级 */
let watchdogOn = false
function startWatchdog() {
  if (watchdogOn) return; watchdogOn = true
  setInterval(() => {
    let changed = false
    db.alerts.forEach(a => {
      if (a.status === 'pending' && a.deadline && Date.now() > a.deadline) {
        a.status = 'auto'
        pushLog(a, '核验倒计时结束未确认，系统自动呼叫长辈电话，并按优先级联动备用看护人、物业与120急救')
        changed = true; resetPosture('救援已自动升级，前端恢复监测画面')
      }
    })
    if (changed) { persist(); syncBadge(); emit('alerts'); toast('有告警超时未确认，已自动升级紧急救援') }
  }, 1000)
}
function syncBadge() {
  const n = db.alerts.filter(a => a.status === 'pending').length
  try {
    if (n > 0) wx.setTabBarBadge({ index: 2, text: String(n) })
    else wx.removeTabBarBadge({ index: 2 })
  } catch (e) { }
}

/* ---------- AI 姿态识别引擎：后端录入跌倒姿态 → 自动判定摔倒 ---------- */
let aiState = { active: false, start: 0 }, aiTimer = null
function getAi() {
  if (!aiState.active) return { active: false, p: 0, conf: 62, left: 5 }
  const p = Math.min(1, (Date.now() - aiState.start) / 5000)
  return { active: true, p, conf: Math.round(62 + 27 * p), left: Math.max(0, Math.ceil(5 - p * 5)) }
}
function deviceFallEntry() {
  ensureDevice()
  if (sim.posture === 'lying') { toast('已处于跌倒识别流程中'); return }
  sim.posture = 'lying'; sim.fallAt = Date.now(); persist()
  pushEvent('⚠️', '感知设备后端录入异常姿态：' + sim.room + '水平倒地，毫米波同步确认', 'posture')
  aiState = { active: true, start: Date.now() }
  emit('device'); emit('ai')
  clearInterval(aiTimer)
  aiTimer = setInterval(() => {
    if (!aiState.active) { clearInterval(aiTimer); return }
    const p = (Date.now() - aiState.start) / 5000
    emit('ai')
    if (p >= 1) { clearInterval(aiTimer); aiState.active = false; sendAlert('fall', { conf: 89 }); emit('ai') }
  }, 250)
}
function aiCancel() {
  clearInterval(aiTimer); aiState.active = false
  if (sim) { sim.posture = 'standing'; persist() }
  pushEvent('✅', 'AI 复核解除：姿态恢复站立，判定为误判，继续正常监测', 'posture')
  toast('已解除复核，恢复监测')
  emit('device'); emit('ai')
}

/* ---------- 用药提醒 ---------- */
function medState(m) {
  if (m.takenDate === todayKey()) return 'taken'
  const now = new Date(), p = String(m.time || '08:00').split(':')
  const diff = (now.getHours() * 60 + now.getMinutes()) - ((+p[0]) * 60 + (+p[1]))
  return (diff >= -15 && diff <= 120) ? 'due' : 'wait'
}
function takeMed(id) {
  const e = activeElder(); if (!e) return
  const m = (e.meds || []).find(x => x.id === id); if (!m) return
  m.takenDate = todayKey(); persist()
  pushEvent('💊', '已确认服用「' + m.name + '」，智能药盒开启记录')
  emit('elders'); toast('已记录服用，家人端同步可见')
}

/* ---------- 档案 ---------- */
const DISEASES = ['高血压', '糖尿病', '心脏病', '关节炎', '哮喘', '脑卒中史', '骨质疏松']
function saveElder(data, id) {
  let e
  if (id) { e = db.elders.find(x => x.id === id); if (!e) return null }
  else { e = { id: uid() }; db.elders.push(e) }
  Object.assign(e, data)
  write('sg_curElder', e.id)
  persist(); ensureDevice(); syncBadge()
  emit('elders'); emit('device')
  return e
}
function removeElder(id) {
  db.elders = db.elders.filter(e => e.id !== id)
  db.alerts = db.alerts.filter(a => a.elderId !== id)
  persist()
  if (!db.elders.length) { db.device = null; sim = null; persist() }
  syncBadge(); emit('elders'); emit('alerts'); emit('device')
}

/* ---------- 登录 / 会话 ---------- */
function login(phone, name) { db.sess = { phone, name }; write(KEY.sess, db.sess) }
function logout() { try { wx.removeStorageSync(KEY.sess) } catch (e) { } db.sess = null }
function elderPending() { const e = activeElder(); return e ? db.alerts.find(a => a.elderId === e.id && a.status === 'pending') : null }

module.exports = {
  KEY, db, persist, on, off, emit,
  pad, fmtT, fmtDT, todayKey, uid, toast, pushEvent,
  activeElder, setCurElder, requestWizard, consumeWizard,
  ROOMS, POSTURE_TEXT, ensureDevice, getSim, startEngine, startWatchdog,
  TYPE, sendAlert, resolveAlert, resetPosture, syncBadge,
  getAi, deviceFallEntry, aiCancel,
  medState, takeMed,
  DISEASES, saveElder, removeElder,
  login, logout, elderPending
}
