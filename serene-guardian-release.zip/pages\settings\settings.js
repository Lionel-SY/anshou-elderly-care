/* 家人端 · 设置 */
const store = require('../../utils/store.js')

const VERIFY = [30, 60, 90, 120]

Page({
  data: { name: '—', phone: '—', verifyOpts: VERIFY.map(v => v + ' 秒'), verifyIdx: 1, battery: 88 },

  onShow() {
    if (!store.db.sess) { wx.reLaunch({ url: '/pages/login/login' }); return }
    this._r = () => this.render()
    store.on('device', this._r)
    this.render()
  },
  onHide() { if (this._r) store.off('device', this._r) },
  onUnload() { if (this._r) store.off('device', this._r) },

  render() {
    const u = store.db.sess || {}
    const sim = store.ensureDevice()
    this.setData({
      name: u.name || '—',
      phone: u.phone ? u.phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2') : '—',
      verifyIdx: Math.max(0, VERIFY.indexOf(store.db.settings.verify)),
      battery: Math.round(sim.battery)
    })
  },

  onVerify(e) {
    const v = VERIFY[+e.detail.value]
    store.db.settings.verify = v
    store.persist()
    store.toast('核验倒计时已更新为 ' + v + ' 秒')
  },

  logout() {
    wx.showModal({
      title: '退出登录', content: '退出登录？本机档案数据将保留。',
      success: r => {
        if (!r.confirm) return
        store.logout()
        wx.reLaunch({ url: '/pages/login/login' })
      }
    })
  }
})
