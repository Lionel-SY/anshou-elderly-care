/* ============================================================
   Serene Guardian · 温情守护远程照护系统（微信小程序版）
   登录 → 长辈档案(病史/住址/用药) → 感知设备自动录入(姿态/睡眠/活动)
   → 后端录入跌倒姿态 → AI 姿态识别自动判定摔倒 → 家人端实时报警
   ============================================================ */
const store = require('./utils/store.js')

App({
  onLaunch() {
    store.startEngine()
    store.startWatchdog()
    store.syncBadge()
  }
})
