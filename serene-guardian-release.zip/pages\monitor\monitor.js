/* 家人端 · 监控中心：实时画面 + 感知设备 + 后端录入跌倒姿态 → AI 自动识别 */
const store = require('../../utils/store.js')

const DEV_META = {
  cam: ['📷 客厅 AI 视觉守护仪', '1080P · AI边缘计算 · 端侧识别不联网'],
  wave: ['📡 卫生间毫米波监测仪', '77GHz 毫米波 · 无摄像头 · 物理遮蔽设计'],
  pad: ['🛏️ 卧室睡眠感应垫', '离床监测 · 睡眠分期 · 起夜感应']
}

Page({
  data: {
    dev: 'cam', monTitle: DEV_META.cam[0], monMeta: DEV_META.cam[1],
    lying: false, postureText: '姿态正常 · 站立',
    aiShow: false, aiPct: 0, aiConf: 62, aiLeft: 5,
    devices: [], feed: [], feedState: '实时'
  },

  onShow() {
    if (!store.db.sess) { wx.reLaunch({ url: '/pages/login/login' }); return }
    this._d = () => this.render()
    this._a = () => this.renderAi()
    store.on('device', this._d)
    store.on('events', this._d)
    store.on('ai', this._a)
    this.render(); this.renderAi()
  },
  onHide() { this.unsub() },
  onUnload() { this.unsub() },
  unsub() {
    if (this._d) { store.off('device', this._d); store.off('events', this._d) }
    if (this._a) store.off('ai', this._a)
  },

  setDev(e) {
    const d = e.currentTarget.dataset.d
    this.setData({ dev: d, monTitle: DEV_META[d][0], monMeta: DEV_META[d][1] })
  },

  render() {
    const sim = store.ensureDevice()
    const lying = sim.posture === 'lying'
    const devices = [
      { ic: '📷', n: '客厅 AI 视觉守护仪', s: '在线 · 1080P 轮廓模式 · 当前姿态：' + (store.POSTURE_TEXT[sim.posture] || ''), warn: lying },
      { ic: '📡', n: '卫生间毫米波监测仪', s: '在线 · 77GHz · 静止超时监测中', warn: false },
      { ic: '🛏️', n: '卧室睡眠感应垫', s: '在线 · 昨夜睡眠 ' + ((sim.sleep || '—').split('·')[1] || '—'), warn: false },
      { ic: '⌚', n: '健康手环', s: '在线 · 电量 ' + Math.round(sim.battery) + '% · 心率 ' + Math.round(sim.hr) + ' bpm', warn: !!sim.forceHR }
    ]
    const feed = store.db.events.filter(v => v.kind === 'posture').slice(0, 6).map(v => ({
      ts: v.ts, icon: v.icon, text: v.text, time: store.fmtT(v.ts),
      cls: (v.icon === '⚠️' || v.icon === '🚨') ? 'r' : (v.icon === '✅' ? 'g' : '')
    }))
    this.setData({
      lying,
      postureText: store.POSTURE_TEXT[sim.posture] || store.POSTURE_TEXT.standing,
      devices, feed
    })
  },

  renderAi() {
    const ai = store.getAi()
    this.setData({
      aiShow: ai.active,
      aiPct: Math.round(ai.p * 100),
      aiConf: ai.conf,
      aiLeft: ai.left,
      feedState: ai.active ? 'AI 复核中' : '实时'
    })
  },

  fallEntry() {
    store.deviceFallEntry()
    this.render(); this.renderAi()
  },
  cancelAi() { store.aiCancel() },
  demo(e) { store.toast(e.currentTarget.dataset.t) }
})
