/* 老人端：大字体简洁界面 + 一键 SOS + 状态/用药展示 */
const store = require('../../utils/store.js')

Page({
  data: {
    clock: '', elderName: '长辈', pending: false,
    hr: '--', steps: 0, act: '休息中', sleep: '--', battery: 88,
    meds: [],
    sosShow: false, sosCount: 3, sentShow: false, sentIc: '🆘'
  },

  onShow() {
    if (!store.db.sess) { wx.reLaunch({ url: '/pages/login/login' }); return }
    this._r = () => this.render()
    store.on('device', this._r); store.on('elders', this._r); store.on('alerts', this._r)
    this.startClock()
    this.render()
  },
  onHide() { this.unsub(); this.stopClock() },
  onUnload() { this.unsub(); this.stopClock() },
  unsub() {
    if (this._r) { store.off('device', this._r); store.off('elders', this._r); store.off('alerts', this._r) }
  },

  startClock() {
    this.stopClock()
    const tick = () => {
      const d = new Date()
      const week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()]
      this.setData({ clock: (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + week + ' · ' + store.fmtT(Date.now()) })
    }
    tick(); this._ck = setInterval(tick, 1000)
  },
  stopClock() { if (this._ck) { clearInterval(this._ck); this._ck = null } },

  render() {
    const e = store.activeElder()
    const sim = store.ensureDevice()
    const p = store.elderPending()
    const actMap = { rest: '休息中', walk: '散步中', sleep: '睡眠中' }
    const meds = e ? (e.meds || []).slice().sort((a, b) => a.time.localeCompare(b.time))
      .map(m => Object.assign({}, m, { st: store.medState(m), disease: m.disease || '日常用药' })) : []
    this.setData({
      elderName: e ? e.name : '长辈',
      pending: !!p,
      hr: Math.round(sim.hr),
      steps: sim.steps,
      act: actMap[sim.activity] || '休息中',
      sleep: (sim.sleep || '—').split('·')[1] || '—',
      battery: Math.round(sim.battery),
      meds
    })
  },

  /* SOS：3 秒倒计时 → 发送 */
  startSos() {
    let n = 3
    this.setData({ sosShow: true, sosCount: n })
    try { wx.vibrateShort({}) } catch (e) { }
    clearInterval(this._sos)
    this._sos = setInterval(() => {
      n--
      if (n <= 0) {
        clearInterval(this._sos)
        this.setData({ sosShow: false })
        store.sendAlert('sos')
        this.setData({ sentShow: true, sentIc: store.TYPE.sos.ic })
      } else {
        this.setData({ sosCount: n })
        try { wx.vibrateShort({}) } catch (e) { }
      }
    }, 1000)
  },
  cancelSos() {
    clearInterval(this._sos)
    this.setData({ sosShow: false })
    store.toast('已取消报警')
  },
  closeSent() { this.setData({ sentShow: false }) },

  takeMed(e) { store.takeMed(e.currentTarget.dataset.id) },

  demoHr() {
    store.ensureDevice().forceHR = true
    store.toast('已模拟心率快速上升，若持续偏高将自动报警')
  },
  demoFall() {
    store.deviceFallEntry()
    store.toast('已向守护系统录入跌倒姿态，AI 自动识别中…')
  },

  goFamily() { wx.switchTab({ url: '/pages/home/home' }) }
})
