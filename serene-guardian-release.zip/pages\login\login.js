/* 登录页：手机验证码（演示验证码 246810）→ 完善长辈档案 */
const store = require('../../utils/store.js')

Page({
  data: { tab: 'phone', phone: '', code: '', name: '', agree: false },

  onLoad() {
    if (store.db.sess) this.enter()
  },

  setTab(e) {
    const t = e.currentTarget.dataset.t
    this.setData({ tab: t })
    if (t === 'wx') store.toast('演示环境请使用「手机验证码登录」')
  },
  onPhone(e) { this.setData({ phone: e.detail.value }) },
  onCode(e) { this.setData({ code: e.detail.value }) },
  onName(e) { this.setData({ name: e.detail.value }) },
  toggleAgree() { this.setData({ agree: !this.data.agree }) },

  getCode() {
    const p = this.data.phone.trim()
    if (!/^\d{11}$/.test(p)) { store.toast('请输入 11 位有效手机号'); return }
    store.toast('验证码已发送至 ' + p.slice(0, 3) + '****' + p.slice(7) + '：246810')
    setTimeout(() => this.setData({ code: '246810' }), 900)
  },

  submit() {
    const { phone, code, name, agree } = this.data
    if (!/^\d{11}$/.test(phone.trim())) { store.toast('请输入 11 位有效手机号'); return }
    if (code.trim() !== '246810') { store.toast('验证码不正确（演示验证码 246810）'); return }
    if (!name.trim()) { store.toast('请填写监护人称呼'); return }
    if (!agree) { store.toast('请先阅读并勾选协议'); return }
    store.login(phone.trim(), name.trim())
    this.enter()
  },

  enter() {
    if (!store.db.elders.length) {
      store.requestWizard()
      store.toast('首次使用，请先完善长辈看护档案')
      wx.switchTab({ url: '/pages/elders/elders' })
    } else {
      store.ensureDevice()
      wx.switchTab({ url: '/pages/home/home' })
    }
  }
})
