/* 家人端 · 首页：实时状态 + 定位 + 起居节律 + 用药 + 联络通道 */
const store = require('../../utils/store.js')

Page({
  data: {
    elders: [], elderNames: [], elderIdx: 0, pending: 0, elder: null,
    heroAlert: false, heroChip: '', heroTime: '', heroTitle: '', avatarTxt: '',
    room: '客厅', hrTxt: '--', steps: 0, sleepShort: '--', lying: false, postureText: '姿态正常 · 站立',
    mapLat: 39.9087, mapLng: 116.3975, markers: [],
    rhythm: [], meds: [], medSummary: ''
  },

  onShow() {
    if (!store.db.sess) { wx.reLaunch({ url: '/pages/login/login' }); return }
    this._d = () => this.render()
    this._e = () => this.render()
    store.on('device', this._d)
    store.on('events', this._e); store.on('elders', this._e); store.on('alerts', this._e)
    this.render()
  },
  onHide() { this.unsub() },
  onUnload() { this.unsub() },
  unsub() {
    if (this._d) store.off('device', this._d)
    if (this._e) { store.off('events', this._e); store.off('elders', this._e); store.off('alerts', this._e) }
  },

  render() {
    const elders = store.db.elders, elder = store.activeElder()
    const pending = store.db.alerts.filter(a => a.status === 'pending').length
    const sim = store.ensureDevice()
    const d = {
      elders,
      elderNames: elders.map(e => e.name + ' ' + e.age + '岁'),
      elderIdx: Math.max(0, elders.findIndex(x => elder && x.id === elder.id)),
      pending, elder
    }
    if (elder) {
      const p = store.db.alerts.find(a => a.elderId === elder.id && a.status === 'pending')
      d.heroAlert = !!p
      d.heroChip = p ? '守护提醒 · 需要关注' : '目前安全 · 平稳安心'
      d.heroTime = p ? store.fmtT(p.ts) : '刚刚'
      d.heroTitle = p ? (store.TYPE[p.type].t + ' · ' + p.room) : ('一切安好 · ' + elder.name + '在' + sim.room + (sim.activity === 'walk' ? '活动' : '休息'))
      d.avatarTxt = (elder.name || '长')[0]
      const lat = elder.loc ? elder.loc.lat : 39.9087, lng = elder.loc ? elder.loc.lng : 116.3975
      d.mapLat = lat; d.mapLng = lng
      d.markers = [{ id: 1, latitude: lat, longitude: lng, width: 28, height: 28, callout: { content: elder.name + ' · ' + sim.room, color: '#ffffff', bgColor: '#FE8E28', borderRadius: 10, padding: 6, display: 'ALWAYS', fontSize: 12 } }]
      const meds = (elder.meds || []).slice().sort((a, b) => a.time.localeCompare(b.time))
        .map(m => Object.assign({}, m, { st: store.medState(m), disease: m.disease || '日常用药' }))
      d.meds = meds
      const due = meds.filter(m => m.st === 'due').length
      d.medSummary = meds.length ? (due ? due + ' 项待服用' : '今日均已按时') : ''
    }
    d.room = sim.room
    d.hrTxt = Math.round(sim.hr)
    d.steps = sim.steps
    d.sleepShort = (sim.sleep || '—').split('·')[1] || '—'
    d.lying = sim.posture === 'lying'
    d.postureText = store.POSTURE_TEXT[sim.posture] || store.POSTURE_TEXT.standing
    d.rhythm = store.db.events.filter(v => v.kind !== 'posture').slice(0, 5)
      .map(v => ({ ts: v.ts, icon: v.icon, text: v.text, time: store.fmtT(v.ts) }))
    this.setData(d)
  },

  onElderPick(e) {
    const el = this.data.elders[+e.detail.value]
    if (el) store.setCurElder(el.id)
  },
  goAlerts() { wx.switchTab({ url: '/pages/alerts/alerts' }) },
  goMonitor() { wx.switchTab({ url: '/pages/monitor/monitor' }) },
  goElders() { wx.switchTab({ url: '/pages/elders/elders' }) },
  goElder() { wx.navigateTo({ url: '/pages/elder/elder' }) },
  refreshLoc() { this.render(); store.toast('位置已更新：' + store.getSim().room) },
  openMap() {
    const el = this.data.elder
    if (el && el.loc) wx.openLocation({ latitude: el.loc.lat, longitude: el.loc.lng, name: el.name + ' 当前位置', address: el.address || '' })
    else store.toast('暂无定位坐标，可在档案页同步当前位置')
  },
  callElder() { store.toast('正在通过守护网关拨打长辈免提电话…（演示）') },
  callProperty() {
    const el = this.data.elder
    if (el && el.propertyPhone) { store.toast('正在呼叫小区物业 ' + el.propertyPhone + '…（演示）'); return }
    store.toast('请先在档案中填写物业电话')
    wx.switchTab({ url: '/pages/elders/elders' })
  },
  demo(e) { store.toast(e.currentTarget.dataset.t) }
})
