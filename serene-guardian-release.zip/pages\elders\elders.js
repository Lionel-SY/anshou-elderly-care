/* 家人端 · 老人档案：增删改 + 病史 + 用药 + 住址定位 + 建档向导 */
const store = require('../../utils/store.js')

const GENDERS = ['女', '男']
const LIVINGS = ['独自居住', '与配偶同住', '家庭同住']

Page({
  data: {
    elder: null, avatarTxt: '长', room: '客厅', locText: '未同步',
    genders: GENDERS, livings: LIVINGS,
    wizOpen: false, wizId: null,
    wiz: {}, disList: []
  },

  onShow() {
    if (!store.db.sess) { wx.reLaunch({ url: '/pages/login/login' }); return }
    this._r = () => this.render()
    store.on('elders', this._r); store.on('device', this._r)
    this.render()
    if (store.consumeWizard()) setTimeout(() => this.openAdd(), 350)
  },
  onHide() { this.unsub() },
  onUnload() { this.unsub() },
  unsub() { if (this._r) { store.off('elders', this._r); store.off('device', this._r) } },

  render() {
    const e = store.activeElder()
    const sim = store.ensureDevice()
    this.setData({
      elder: e,
      avatarTxt: e ? (e.name || '长')[0] : '长',
      room: sim.room,
      locText: e && e.loc ? '已同步坐标（可在首页地图查看）' : '未同步坐标'
    })
  },

  /* ---------- 向导 ---------- */
  openAdd() { this.openWiz(null) },
  openEdit() { this.openWiz(store.activeElder()) },
  openWiz(e) {
    const disList = store.DISEASES.map(n => ({ name: n, on: !!(e && (e.diseases || []).includes(n)) }))
    this.setData({
      wizOpen: true,
      wizId: e ? e.id : null,
      disList,
      wiz: {
        name: e ? e.name : '', age: e ? String(e.age) : '',
        genderIdx: e && e.gender === '男' ? 1 : 0,
        livingIdx: Math.max(0, LIVINGS.indexOf(e ? e.living : '独自居住')),
        address: e ? e.address || '' : '', propertyPhone: e ? e.propertyPhone || '' : '',
        note: e ? e.note || '' : '',
        meds: e ? JSON.parse(JSON.stringify(e.meds || [])) : [],
        contacts: e ? JSON.parse(JSON.stringify(e.contacts || [])) : [],
        rMorning: e ? e.rMorning || '06:30-07:15' : '06:30-07:15',
        rNoon: e ? e.rNoon || '12:45-14:00' : '12:45-14:00',
        rNight: e ? e.rNight || '21:30-06:00' : '21:30-06:00',
        loc: e && e.loc ? e.loc : null
      }
    })
  },
  closeWiz() { this.setData({ wizOpen: false }) },

  onWizInput(e) { this.setData({ ['wiz.' + e.currentTarget.dataset.f]: e.detail.value }) },
  onGender(e) { this.setData({ 'wiz.genderIdx': +e.detail.value }) },
  onLiving(e) { this.setData({ 'wiz.livingIdx': +e.detail.value }) },
  toggleDis(e) { this.setData({ ['disList[' + e.currentTarget.dataset.i + '].on']: !this.data.disList[e.currentTarget.dataset.i].on }) },

  onRowInput(e) {
    const { f, k, i } = e.currentTarget.dataset
    this.setData({ ['wiz.' + f + '[' + i + '].' + k]: e.detail.value })
  },
  onMedTime(e) { this.setData({ ['wiz.meds[' + e.currentTarget.dataset.i + '].time']: e.detail.value }) },
  addRow(e) {
    const f = e.currentTarget.dataset.f
    const row = f === 'meds' ? { id: store.uid(), name: '', time: '08:00', disease: '' } : { id: store.uid(), name: '', relation: '', phone: '' }
    this.setData({ ['wiz.' + f]: this.data.wiz[f].concat(row) })
  },
  delRow(e) {
    const { f, i } = e.currentTarget.dataset
    const arr = this.data.wiz[f].slice(); arr.splice(i, 1)
    this.setData({ ['wiz.' + f]: arr })
  },

  fillDemo() {
    const disList = this.data.disList.map(d => ({ name: d.name, on: d.on || d.name === '高血压' || d.name === '关节炎' }))
    this.setData({
      disList,
      'wiz.name': '李秀英', 'wiz.age': '76',
      'wiz.address': '阳光雅苑小区 3 号楼 2 单元 102 室',
      'wiz.propertyPhone': '010-88562200',
      'wiz.meds': [{ id: store.uid(), name: '苯磺酸氨氯地平片', time: '08:30', disease: '高血压' }],
      'wiz.contacts': [{ id: store.uid(), name: '张震', relation: '女儿（主要监护）', phone: '138****5678' }]
    })
    store.toast('已填入示例数据')
  },

  wizUseLoc() {
    store.toast('正在获取当前位置…')
    wx.getLocation({
      type: 'gcj02',
      success: p => {
        this.setData({
          'wiz.address': '（当前定位）' + p.latitude.toFixed(4) + ', ' + p.longitude.toFixed(4) + ' 附近',
          'wiz.loc': { lng: +p.longitude.toFixed(6), lat: +p.latitude.toFixed(6) }
        })
        store.toast('已填入当前位置')
      },
      fail: () => store.toast('未获得定位权限，请手动填写')
    })
  },

  saveWiz() {
    const w = this.data.wiz
    const name = (w.name || '').trim(), age = +w.age
    if (!name) { store.toast('请填写长辈称呼'); return }
    if (!age || age < 40 || age > 130) { store.toast('请填写有效年龄'); return }
    const data = {
      name, age,
      gender: GENDERS[w.genderIdx], living: LIVINGS[w.livingIdx],
      address: (w.address || '').trim(), propertyPhone: (w.propertyPhone || '').trim(),
      note: (w.note || '').trim(),
      diseases: this.data.disList.filter(d => d.on).map(d => d.name),
      meds: w.meds.filter(m => (m.name || '').trim()),
      contacts: w.contacts.filter(c => (c.name || '').trim()),
      rMorning: w.rMorning, rNoon: w.rNoon, rNight: w.rNight
    }
    if (w.loc) data.loc = w.loc
    const e = store.saveElder(data, this.data.wizId)
    this.setData({ wizOpen: false })
    this.render()
    store.toast(e.meds.length ? '已保存档案，将按「' + e.meds[0].time + '」等时间提醒用药' : '档案已保存，手环守护已开启')
  },

  useLoc() {
    const e = store.activeElder(); if (!e) return
    store.toast('正在获取当前位置…')
    wx.getLocation({
      type: 'gcj02',
      success: p => {
        e.loc = { lng: +p.longitude.toFixed(6), lat: +p.latitude.toFixed(6) }
        if (!e.address) e.address = '当前位置 ' + e.loc.lat + ',' + e.loc.lng
        store.persist(); store.emit('elders')
        store.toast('已同步当前位置')
      },
      fail: () => store.toast('未获得定位权限，可手动填写住址')
    })
  },

  removeElder() {
    const e = store.activeElder(); if (!e) return
    wx.showModal({
      title: '删除档案', content: '确定删除该长辈档案？关联的用药提醒与守护数据将一并清除。',
      confirmColor: '#DC2626',
      success: r => {
        if (!r.confirm) return
        store.removeElder(e.id)
        this.render()
        store.toast('已删除')
        if (!store.db.elders.length) wx.reLaunch({ url: '/pages/login/login' })
      }
    })
  }
})
